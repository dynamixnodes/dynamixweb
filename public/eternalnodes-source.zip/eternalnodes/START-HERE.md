# EternalNodes – Run the Website

Two ways to run this site from the zip.

## Option 1 — Quickest (no install) — Run the pre-built site

The `dist/` folder is already built. Serve it with any static server:

**With Python (already installed on most computers):**
```
cd dist
python -m http.server 8080
```
Then open: http://localhost:8080

**With Node.js:**
```
npx serve dist
```

> ⚠️ Do NOT just double-click `dist/index.html`. Modern browsers block
> module scripts when opened via `file://`. You MUST serve it over http.

## Option 2 — Develop / edit the source

Requires Node 18+ and npm (or bun).

```
npm install
npm run dev
```
Then open the URL it prints (usually http://localhost:8080).

To rebuild the static site:
```
npm run build
```
The output goes into `dist/`.

## Backend

The backend (database, auth, edge functions) runs on Lovable Cloud and is
already configured via the included `.env` style settings inside
`src/integrations/supabase/client.ts`. No setup needed to use the live
backend.
