import { useState, useRef } from "react";
import { Check, Cpu, HardDrive, Server, Sparkles, Lightbulb, ChevronDown, ArrowRight, Shield, Clock, Zap, Globe, Send, Database, Archive, Layers } from "lucide-react";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Slider } from "@/components/ui/slider";
import { supabase } from "@/integrations/supabase/client";

const minecraftPlans = [
  { name: "Eternal - Dirt", ram: 2, cpu: 0.5, storage: 8, priceINR: 20 },
  { name: "Eternal - Copper", ram: 4, cpu: 1, storage: 16, priceINR: 45 },
  { name: "Eternal - Iron", ram: 8, cpu: 2, storage: 32, priceINR: 90 },
  { name: "Eternal - Gold", ram: 12, cpu: 4, storage: 48, priceINR: 180 },
  { name: "Eternal - Diamond", ram: 16, cpu: 6, storage: 64, priceINR: 365 },
  { name: "Eternal - Emerald", ram: 32, cpu: 8, storage: 128, priceINR: 630 },
  { name: "Eternal - Netherite", ram: 64, cpu: 12, storage: 256, priceINR: 1100 },
  { name: "Eternal - Enderium", ram: 256, cpu: 30, storage: 1024, priceINR: 4500 },
];

// Base plan for custom pricing: 1GB RAM, 0.25 vCore, 4GB Storage = ₹10
const basePlan = { ram: 1, cpu: 0.25, storage: 4, priceINR: 10 };

const commonFeatures = ["Mod Support", "24/7 Uptime", "Low Latency", "DDoS Protection"];

const cpuSteps = [0.25, 0.5, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30];

function estimatePrice(ram: number, cpu: number, storage: number): number {
  // Include base plan (1GB/0.25vCore/4GB = ₹10) for accurate low-end pricing
  const allPlans = [basePlan, ...minecraftPlans];
  const score = ram + cpu * 4 + storage * 0.25;

  const planScores = allPlans.map(p => ({ ...p, score: p.ram + p.cpu * 4 + p.storage * 0.25 }));

  if (score <= planScores[0].score) return planScores[0].priceINR;
  if (score >= planScores[planScores.length - 1].score) return planScores[planScores.length - 1].priceINR;

  let lower = planScores[0];
  let upper = planScores[planScores.length - 1];

  for (let i = 0; i < planScores.length - 1; i++) {
    if (score >= planScores[i].score && score <= planScores[i + 1].score) {
      lower = planScores[i];
      upper = planScores[i + 1];
      break;
    }
  }

  const t = (score - lower.score) / (upper.score - lower.score);
  return Math.round(lower.priceINR + t * (upper.priceINR - lower.priceINR));
}

const GameHostingContent = () => {
  const { formatPrice, currency } = useCurrency();
  const [processor, setProcessor] = useState<"AMD EPYC" | "Intel Xeon">("AMD EPYC");
  const [processorOpen, setProcessorOpen] = useState(false);
  const [plansProcessor, setPlansProcessor] = useState<"AMD EPYC" | "Intel Xeon">("AMD EPYC");
  const [ram, setRam] = useState(4);
  const [cpu, setCpu] = useState(1);
  const [cpuIndex, setCpuIndex] = useState(2);
  const [storage, setStorage] = useState(8);
  const [aiInput, setAiInput] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const processorRef = useRef<HTMLDivElement>(null);

  const customMultiplier = processor === "Intel Xeon" ? 0.6 : 1;
  const plansMultiplier = plansProcessor === "Intel Xeon" ? 0.6 : 1;
  const customPrice = Math.round(estimatePrice(ram, cpu, storage) * customMultiplier);

  const handleCpuChange = (val: number[]) => {
    const idx = val[0];
    setCpuIndex(idx);
    setCpu(cpuSteps[idx] || 0.25);
  };

  const handleAiSuggest = async () => {
    if (!aiInput.trim() || aiLoading) return;
    setAiLoading(true);
    setAiResponse("");
    try {
      const planInfo = minecraftPlans.map(p =>
        `${p.name}: ${p.ram}GB RAM, ${p.cpu} vCore(s), ${p.storage}GB Storage - ${formatPrice(p.priceINR)}/mo`
      ).join("\n");

      const res = await supabase.functions.invoke("minecraft-suggest", {
        body: { message: aiInput, plans: planInfo, currency },
      });

      if (res.error) throw res.error;
      setAiResponse(res.data?.suggestion || "Sorry, I couldn't generate a suggestion.");
    } catch {
      setAiResponse("Failed to get suggestion. Please try again.");
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="space-y-24">
      {/* Minecraft Badge */}
      <div className="text-center">
        <span className="inline-block px-6 py-2.5 rounded-full gradient-primary text-primary-foreground text-sm font-bold tracking-wide pointer-events-none select-none">
          Minecraft
        </span>
        <div className="mt-6 inline-flex items-center gap-2 p-1 rounded-full bg-card border border-border">
          {(["AMD EPYC", "Intel Xeon"] as const).map((proc) => (
            <button
              key={proc}
              onClick={() => setPlansProcessor(proc)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
                plansProcessor === proc
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {proc}
            </button>
          ))}
        </div>
      </div>

      {/* Plan Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 max-w-7xl mx-auto">
        {minecraftPlans.map((plan, i) => (
          <div
            key={i}
            className="relative p-8 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_40px_hsl(48_100%_50%/0.2)]"
          >
            <h3 className="text-lg font-bold text-foreground mb-2">{plan.name}</h3>
            <p className="text-3xl font-bold gradient-text mb-6">{formatPrice(Math.round(plan.priceINR * plansMultiplier))}<span className="text-sm text-muted-foreground font-normal">/mo</span></p>
            <ul className="space-y-2.5 mb-6">
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Check className="w-4 h-4 text-primary flex-shrink-0" />
                {plan.ram}GB RAM
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Check className="w-4 h-4 text-primary flex-shrink-0" />
                {plan.cpu} vCore
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Check className="w-4 h-4 text-primary flex-shrink-0" />
                {plan.storage}GB Storage
              </li>
              {commonFeatures.map((f, j) => (
                <li key={j} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Check className="w-4 h-4 text-primary flex-shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            <a
              href="https://discord.com/channels/1478422228323532883/1478432871889895504"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-lg font-medium gradient-primary text-primary-foreground hover:opacity-90 transition-opacity"
            >
              Order Now <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        ))}
      </div>

      {/* Custom Plans Title */}
      <div className="text-center">
        <h2 className="text-2xl md:text-3xl font-bold">
          <span className="text-foreground">Custom </span>
          <span className="gradient-text">Plans</span>
        </h2>
      </div>

      {/* Custom Plan Builder + AI Suggestor */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
        {/* Build Your Custom Plan */}
        <div className="p-8 rounded-2xl bg-card border border-border transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_40px_hsl(48_100%_50%/0.2)]">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <h3 className="text-xl font-bold text-foreground">Build Your Custom Plan</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-8">Select your requirements and we'll show you the best plan for you</p>

          {/* Processor */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Server className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-foreground">Processor</span>
            </div>
            <div ref={processorRef} className="relative">
              <button
                onClick={() => setProcessorOpen(!processorOpen)}
                className="w-full flex items-center justify-between px-4 py-3 rounded-lg bg-muted border border-border text-sm text-foreground"
              >
                {processor}
                <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${processorOpen ? "rotate-180" : ""}`} />
              </button>
              {processorOpen && (
                <div className="absolute top-full mt-1 left-0 right-0 bg-card border border-border rounded-lg py-1 shadow-xl z-10">
                  {(["AMD EPYC", "Intel Xeon"] as const).map((proc) => (
                    <button
                      key={proc}
                      onClick={() => { setProcessor(proc); setProcessorOpen(false); }}
                      className={`w-full text-left px-4 py-2 text-sm transition-colors ${proc === processor ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground hover:bg-muted"}`}
                    >
                      {proc}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* RAM */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <img src="https://www.svgrepo.com/show/456242/ram-memory.svg" alt="RAM" className="w-4 h-4 [filter:brightness(0)_saturate(100%)_invert(78%)_sepia(58%)_saturate(2363%)_hue-rotate(2deg)_brightness(102%)_contrast(102%)]" />
                <span className="text-sm font-medium text-foreground">RAM</span>
              </div>
              <span className="text-sm font-bold text-primary">{ram} GB</span>
            </div>
            <Slider
              value={[ram]}
              onValueChange={(v) => setRam(v[0])}
              min={1}
              max={256}
              step={1}
              className="w-full"
            />
          </div>

          {/* CPU Cores */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-foreground">CPU Cores</span>
              </div>
              <span className="text-sm font-bold text-primary">{cpu} vCore</span>
            </div>
            <Slider
              value={[cpuIndex]}
              onValueChange={handleCpuChange}
              min={0}
              max={cpuSteps.length - 1}
              step={1}
              className="w-full"
            />
          </div>

          {/* Storage */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-foreground">Storage</span>
              </div>
              <span className="text-sm font-bold text-primary">{storage} GB</span>
            </div>
            <Slider
              value={[storage]}
              onValueChange={(v) => setStorage(v[0])}
              min={4}
              max={1024}
              step={4}
              className="w-full"
            />
          </div>

          {/* Price */}
          <div className="p-4 rounded-xl bg-muted border border-border text-center">
            <span className="text-3xl font-bold text-primary">{formatPrice(customPrice)}</span>
            <span className="text-muted-foreground">/month</span>
          </div>
        </div>

        {/* AI Suggestor */}
        <div className="p-8 rounded-2xl bg-card border border-border flex flex-col transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_40px_hsl(48_100%_50%/0.2)]">
          <div className="flex items-center gap-2 mb-2">
            <Lightbulb className="w-5 h-5 text-primary" />
            <h3 className="text-xl font-bold text-foreground">Eternal AI Suggestor</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-6">Tell us what you need and our AI will suggest the perfect Minecraft plan for you</p>

          <div className="flex-1 min-h-[200px] mb-4 p-4 rounded-xl bg-muted border border-border overflow-auto">
            {aiResponse ? (
              <p className="text-sm text-foreground whitespace-pre-wrap">{aiResponse}</p>
            ) : (
              <p className="text-sm text-muted-foreground italic">AI suggestion will appear here...</p>
            )}
            {aiLoading && (
              <div className="flex items-center gap-2 mt-2">
                <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <span className="text-sm text-muted-foreground">Thinking...</span>
              </div>
            )}
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={aiInput}
              onChange={(e) => setAiInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAiSuggest()}
              placeholder="e.g., 20 players survival server with mods"
              className="flex-1 px-4 py-3 rounded-lg bg-muted border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
            <button
              onClick={handleAiSuggest}
              disabled={aiLoading || !aiInput.trim()}
              className="px-4 py-3 rounded-lg gradient-primary text-primary-foreground hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Utility Store */}
      <div className="max-w-6xl mx-auto">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">
          <span className="text-foreground">Utility </span>
          <span className="gradient-text">Store</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Backup */}
          <div className="p-6 rounded-2xl bg-card border border-border transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_40px_hsl(48_100%_50%/0.2)]">
            <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center mb-4">
              <Archive className="w-5 h-5 text-primary-foreground" />
            </div>
            <h3 className="text-lg font-bold text-foreground mb-2">Backup</h3>
            <p className="text-sm text-muted-foreground mb-4">Automatic server backups with easy one-click restoration to keep your data safe.</p>
            <p className="text-2xl font-bold text-primary mb-4">{formatPrice(10)}<span className="text-sm text-muted-foreground font-normal">/unit</span></p>
            <a
              href="https://discord.com/channels/1478422228323532883/1478432871889895504"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-lg font-medium gradient-primary text-primary-foreground hover:opacity-90 transition-opacity"
            >
              Order Now <ArrowRight className="w-4 h-4" />
            </a>
          </div>

          {/* Allocation */}
          <div className="relative p-6 rounded-2xl bg-card border border-border transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_40px_hsl(48_100%_50%/0.2)]">
            <div className="absolute -top-3 right-4 px-3 py-1 rounded-full text-xs font-bold gradient-primary text-primary-foreground">
              EXTERNAL
            </div>
            <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center mb-4">
              <Layers className="w-5 h-5 text-primary-foreground" />
            </div>
            <h3 className="text-lg font-bold text-foreground mb-2">Allocation</h3>
            <p className="text-sm text-muted-foreground mb-4">Additional port allocations for your server to run multiple services simultaneously.</p>
            <p className="text-2xl font-bold text-primary mb-4">{formatPrice(20)}<span className="text-sm text-muted-foreground font-normal">/mo</span></p>
            <a
              href="https://discord.com/channels/1478422228323532883/1478432871889895504"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-lg font-medium gradient-primary text-primary-foreground hover:opacity-90 transition-opacity"
            >
              Order Now <ArrowRight className="w-4 h-4" />
            </a>
          </div>

          {/* Database */}
          <div className="p-6 rounded-2xl bg-card border border-border transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_40px_hsl(48_100%_50%/0.2)]">
            <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center mb-4">
              <Database className="w-5 h-5 text-primary-foreground" />
            </div>
            <h3 className="text-lg font-bold text-foreground mb-2">Database</h3>
            <p className="text-sm text-muted-foreground mb-4">Managed database instances for plugins and mods that require persistent data storage.</p>
            <p className="text-2xl font-bold text-primary mb-4">{formatPrice(15)}<span className="text-sm text-muted-foreground font-normal">/unit</span></p>
            <a
              href="https://discord.com/channels/1478422228323532883/1478432871889895504"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-lg font-medium gradient-primary text-primary-foreground hover:opacity-90 transition-opacity"
            >
              Order Now <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameHostingContent;
